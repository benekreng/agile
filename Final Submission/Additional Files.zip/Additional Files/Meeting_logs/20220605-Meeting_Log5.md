### Date: 5 Jun 22
### Meeting type: Design update
### Attendees: Connor, Ben, Kashka, Thavelarn

## Meeting Plan: Design update 

Meeting Outcomes: The team's designs are coming along well. This week voting options will be created on the team Slack channel for the final Design ideas for the project. Once uploaded the team will vote on the layout and features of the project. 

The team will have a screen share session during next the team meeting next week. This will be to ensure every team member is happy with the Requirement's documentation and where all the resources are for the Midterm.

As the midterm is approaching all team members will start completing the Requirements files within the GitHub/Requirements/Final_Requirements directory of the repo. This will be the central source of knowledge for answering the midterm questions. To avoid missing information these documents will not be altered after 19 June 22. This will allow a week to finalise/write the midterm submission by each team member.

**Tasks**
+ All team:
	+ Vote on designs once uploaded to Slack
    + Update the requirement documents within the Final_Requirements file on the GitHub repo (GitHub/Agile/Requirements/Final_Requirements)
+ Connor:
	+ Create voting options for features + designs on the slack channel.