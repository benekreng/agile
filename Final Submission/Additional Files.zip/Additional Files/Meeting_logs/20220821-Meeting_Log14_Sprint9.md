### Date: 21 Aug 22
### Meeting type: Sprint 8 recap and outline T&E duties 
### Attendees: Connor, Thavelarn

## Meeting Plan: Review sprint 8 progress and outline tasks for the testing an evaluation phase (T&E)

Meeting Outcomes: 

The project has no more development time remaining. We are now into the testing and evaluation phase

All testing will be with friends and family, ideally with the target audience of basic computer users. The following is a rough plan for how the team will achieve testing.

**Blackbox testing.** The team will give the product to users without any context and then assess how they navigate and use the program

**Whitebox testing.** The team will give the product to users with context and allow them access to all areas of the code if necessary. Following this the team will assess how tthe users  navigate and use the program.

**Accessibility testing.** The team will run the program through accessibility testing to ensure it is meeting the minimum requirements required by UK legislation. 


**Tasks**
The team will each test thr program and report the results for the next meeting.
