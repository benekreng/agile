### Meeting did not occur due to schedluing issues with all members of the team

