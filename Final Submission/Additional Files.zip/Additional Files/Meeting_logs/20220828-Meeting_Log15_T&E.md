### Date: 28 Aug 22
### Meeting type: T&E recap 
### Attendees: Connor, Thavelarn, Ben

## Meeting Plan: Review T&E week and then distribute report writing duties

Meeting Outcomes: The team are collating the T&E results for the report. 

Looking ahead to the final report submission the team are going to have an update meeting on 3 Sep 22 at 1400 GMT. This will allow for final changes to be made prior to the final submission on 4 Sep 22. 

A large section of the report has allready been written by Connor. The team will split the remaining elements of the report to optimise efficiency. 

- **Connor.** Conclusion and summary 
- **Ben.** References (from the topics in the lit. review)
- **Thavelarn.** Testing
- **David.** Annex A - Work summary (from the GitHub logs)
- **Kashka.** Kashka has not been seen in weeks and it is unknown if he is still undertaking the module. If he gets in touch duties will be distributed to him.


**Tasks**
Each team member will complete the sections outlined above for the final report.
