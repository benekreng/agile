placeholder - meeting was not possible due to external commitments from 
all team members
