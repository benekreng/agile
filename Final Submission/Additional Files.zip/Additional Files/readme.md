This folder contains all version control logs and additional files like the testing stuff and anything else.

Once the folder is filled, create a zip file of it and submit it.
