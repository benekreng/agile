//function to undo or redo changes to the canvas
function UndoRedoTool(maxSaves) {
    var storedStates = [];
    var currentState = -1;
    var self = this;
    this.maxSaves = maxSaves;
    
    //saves a copy of the canvas to an array and deletes the first element in
    //the array if maximum amount of saves is reached
    this.addState = function() {
        if (currentState+1 >= self.maxSaves) {
            storedStates.shift();
            currentState -= 1;
        }
        storedStates.splice(currentState+1);
        currentState += 1;
        storedStates.push({image: get(), background: backgroundColor});
    };
    
    var setState = function(state) {
        document.getElementById("backgroundpicker").value = storedStates[state].background;
        image(storedStates[state].image, 0, 0);
    };
    
    var updateState = function() {
        //undo changes via user input
        select("#undo").mouseClicked(function() {
            if (currentState > 0) {
                currentState -= 1;
                setState(currentState);
            }
            
        });
        //redo changes via user input
        select("#redo").mouseClicked(function() {
            if (currentState < storedStates.length-1) {
                currentState += 1;
                setState(currentState);
            }
        });
    };
    
    updateState();
}