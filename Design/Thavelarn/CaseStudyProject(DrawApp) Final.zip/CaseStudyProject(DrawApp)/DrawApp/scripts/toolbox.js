//container object for storing the tools. Functions to add new tools and select a tool
function Toolbox() {
	var self = this;
	this.tools = [];
	this.selectedTool = null;

	this.toolbarItemClick = function(toolName) {
		self.selectTool(toolName);
		//call loadPixels to make sure most recent changes are saved to pixel array
		loadPixels();
	}

	//add a tool to the tools array
	this.addTool = function(tool) {
		//check that the object tool has an icon and a name
		if (!tool.hasOwnProperty("name")) {
			alert("make sure your tool has a name");
		}
		this.tools.push(tool);
        select("#" + tool.name).mouseClicked(function() {
            self.toolbarItemClick(tool.name);
        });
		//if no tool is selected (ie. none have been added so far)
		//make this tool the selected one.
		if (this.selectedTool == null) {
			this.selectTool(tool.name);
		}
	};

	this.selectTool = function(toolName) {
		//search through the tools for one that's name matches
		//toolName
		for (var i = 0; i < this.tools.length; i++) {
			if (this.tools[i].name == toolName) {
				//select the tool on the toolbar
				this.selectedTool = this.tools[i];
				select("#" + toolName).disabled = true;

				//if the tool has an options area. Populate it now.
				if (this.selectedTool.hasOwnProperty("populateOptions")) {
					this.selectedTool.populateOptions();
				}
			}
		}
        //enable or disable shape chosing and fill UI for shape tool
        if (this.selectedTool.name == "shape") {
            select("#fill").style("display", "block");
            select("#dropside").style("display", "flex");
            select("#dropside").style("flex-wrap", "wrap");
        }
        else {
            select("#fill").style("display", "none");
            select("#dropside").style("display", "none");
        }
        
        //enable or disable extra cut and copy tool UI
        if (this.selectedTool.name == "cutandcopy") {
            select("#cut").style("display", "block");
            select("#copy").style("display", "block");
        }
        else {
            select("#cut").style("display", "none");
            select("#copy").style("display", "none");
            select("#endpaste").style("display", "none");
            //reset selection state in cut and copy tool
            for (var i = 0; i < this.tools.length; i++) {
                if (this.tools[i].name == "cutandcopy") {
                    this.tools[i].inSelection = true;
                }
            }
        }
	};


}