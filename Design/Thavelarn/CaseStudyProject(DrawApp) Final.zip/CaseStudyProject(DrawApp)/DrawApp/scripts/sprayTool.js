//a tool for drawing dots randomly surrounding a selected area.
function SprayTool() {
	this.name = "spray";
	var points = 13;
	var spread = 10;
    
    //sprays the selected section in the screen
	this.draw = function() {
        strokeWeight(1);
        //only draw when mouse is clicked
		if (mouseIsPressed) {
			for (var i = 0; i < points * size; i++) {
                //choosing a random position around the mouse position to
                //draw a point.
                var randomX = random(mouseX-spread * size, mouseX + spread * size);
                var randomY = random(mouseY-spread * size, mouseY+spread * size);
                
				point(randomX, randomY);
                
                //mirroring based on the state of mirror
                if (mirror == 1) {
                    point(width-randomX, randomY);
                }
                else if (mirror == 2) {
                    point(randomX, height-randomY);
                }
                else if (mirror == 3) {
                    point(width-randomX, randomY);
                    point(randomX, height-randomY);
                    point(width-randomX, height-randomY);
                }
            }    
		}
    }
}