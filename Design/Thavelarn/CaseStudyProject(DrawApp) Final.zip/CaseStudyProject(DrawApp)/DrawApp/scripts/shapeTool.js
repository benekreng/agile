function ShapeTool() {
	this.name = "shape";
    var self = this;
	var startMouseX = -1;
	var startMouseY = -1;
	var drawing = false;
    var filled = false;
    this.shape = 1;
    
    //getting user input on whether the shape should be filled or not
    select("#fill").mouseClicked(function() {
        filled = !filled;
    });

	//draws the shape to the screen 
	this.draw = function() {
        //to change if the shape should be filled or not
        if (filled == false) {
            noFill();
        }
        else {
            noStroke();
        }
        
		//only draw when mouse is clicked
		if (mouseIsPressed){
            this.selectShape();
            strokeWeight(size);
            
			//if it's the start of drawing a new shape
			if (startMouseX == -1) {
				startMouseX = mouseX;
				startMouseY = mouseY;
				drawing = true;
				//save the current pixel Array
				loadPixels();
			}
			else {
				//update the screen with the saved pixels to hide any
				//previous shape between mouse pressed and released
				updatePixels();
                
				//draw the shape
                if (this.shape == 1) {
                    drawSquare(startMouseX, startMouseY, mouseX, mouseY);
                }
				else if (this.shape == 2) {
                    
                    drawCircle(startMouseX, startMouseY, mouseX, mouseY);
                }
                else if (this.shape == 3) {
                    
                    drawTriangle(startMouseX, startMouseY, mouseX, mouseY);
                }
                else if (this.shape == 4) {
                    
                    drawPentagon(startMouseX, startMouseY, mouseX, mouseY);
                }
                else if (this.shape == 5) {
                    
                    drawStar(startMouseX, startMouseY, mouseX, mouseY);
                }
                else if (this.shape == 6) {
                    
                    drawShock(startMouseX, startMouseY, mouseX, mouseY);
                }
			}
		}
		else if(drawing){
			//save the pixels with the most recent shape and reset the
			//drawing bool and start locations
			loadPixels();
			drawing = false;
			startMouseX = -1;
			startMouseY = -1;
		}
	};
    
    //to set which shape should be drawn
    this.selectShape = function() {
        select("#square").mouseClicked(function() {
            self.shape = 1;
        });
        select("#circle").mouseClicked(function() {
            self.shape = 2;
        });
        select("#triangle").mouseClicked(function() {
            self.shape = 3;
        });
        select("#pentagon").mouseClicked(function() {
            self.shape = 4;
        });
        select("#star").mouseClicked(function() {
            self.shape = 5;
        });
        select("#shock").mouseClicked(function() {
            self.shape = 6;
        });
    };
}

//draws a square
function drawSquare(startMouseX, startMouseY, mouseX, mouseY) {
    rect(startMouseX, startMouseY, mouseX-startMouseX, mouseY-startMouseY);
    
    //mirroring based on the state of mirror
    if (mirror == 1) {
        rect(width-startMouseX, startMouseY, -1*(mouseX-startMouseX), mouseY-startMouseY);
    }
    else if (mirror == 2) {
        rect(startMouseX, height-startMouseY, mouseX-startMouseX, -1*(mouseY-startMouseY));
    }
    else if (mirror == 3) {
        rect(width-startMouseX, startMouseY, -1*(mouseX-startMouseX), mouseY-startMouseY);
        rect(startMouseX, height-startMouseY, mouseX-startMouseX, -1*(mouseY-startMouseY));
        rect(width-startMouseX, height-startMouseY, -1*(mouseX-startMouseX), -1*(mouseY-startMouseY));
    }
}

//draws a circle
function drawCircle(startMouseX, startMouseY, mouseX, mouseY) {
    ellipse((startMouseX+mouseX)/2, (startMouseY+mouseY)/2, mouseX-startMouseX, mouseY-startMouseY);
    
    //mirroring based on the state of mirror
    if (mirror == 1) {
        ellipse(width-(startMouseX+mouseX)/2, (startMouseY+mouseY)/2, -1*(mouseX-startMouseX), mouseY-startMouseY);
    }
    else if (mirror == 2) {
        ellipse((startMouseX+mouseX)/2, height-(startMouseY+mouseY)/2, mouseX-startMouseX, -1*(mouseY-startMouseY));
    }
    else if (mirror == 3) {
        ellipse(width-(startMouseX+mouseX)/2, (startMouseY+mouseY)/2, -1*(mouseX-startMouseX), mouseY-startMouseY);
        ellipse((startMouseX+mouseX)/2, height-(startMouseY+mouseY)/2, mouseX-startMouseX, -1*(mouseY-startMouseY));
        ellipse(width-(startMouseX+mouseX)/2, height-(startMouseY+mouseY)/2, -1*(mouseX-startMouseX), -1*(mouseY-startMouseY));
    }
}

//draws a triangle
function drawTriangle(startMouseX, startMouseY, mouseX, mouseY) {
    triangle((startMouseX+mouseX)/2, startMouseY, startMouseX, mouseY, mouseX, mouseY);
    
    //mirroring based on the state of mirror
    if (mirror == 1) {
        triangle(width-(startMouseX+mouseX)/2, startMouseY, width-startMouseX, mouseY, width-mouseX, mouseY);
    }
    else if (mirror == 2) {
        triangle((startMouseX+mouseX)/2, height-startMouseY, startMouseX, height-mouseY, mouseX, height-mouseY);
    }
    else if (mirror == 3) {
        triangle(width-(startMouseX+mouseX)/2, startMouseY, width-startMouseX, mouseY, width-mouseX, mouseY);
        triangle((startMouseX+mouseX)/2, height-startMouseY, startMouseX, height-mouseY, mouseX, height-mouseY);
        triangle(width-(startMouseX+mouseX)/2, height-startMouseY, width-startMouseX, height-mouseY, width-mouseX, height-mouseY);
    }
}

//draws a pentagon
function drawPentagon(startMouseX, startMouseY, mouseX, mouseY) {
    beginShape();
    vertex((startMouseX+mouseX)/2, startMouseY);
    vertex(startMouseX, startMouseY-(startMouseY-mouseY)*7/20);
    vertex(startMouseX-(startMouseX-mouseX)/5, mouseY);
    vertex(startMouseX-(startMouseX-mouseX)*4/5, mouseY);
    vertex(mouseX, startMouseY-(startMouseY-mouseY)*7/20);
    endShape(CLOSE);
    
    //mirroring based on the state of mirror
    if (mirror == 1) {
        beginShape();
        vertex(width-(startMouseX+mouseX)/2, startMouseY);
        vertex(width-startMouseX, startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)/5), mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/5), mouseY);
        vertex(width-mouseX, startMouseY-(startMouseY-mouseY)*7/20);
        endShape(CLOSE);
    }
    else if (mirror == 2) {
        beginShape();
        vertex((startMouseX+mouseX)/2, height-startMouseY);
        vertex(startMouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)/5, height-mouseY);
        vertex(startMouseX-(startMouseX-mouseX)*4/5, height-mouseY);
        vertex(mouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        endShape(CLOSE);
    }
    else if (mirror == 3) {
        beginShape();
        vertex(width-(startMouseX+mouseX)/2, startMouseY);
        vertex(width-startMouseX, startMouseY-(startMouseY-mouseY)*3/10);
        vertex(width-(startMouseX-(startMouseX-mouseX)/5), mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/5), mouseY);
        vertex(width-mouseX, startMouseY-(startMouseY-mouseY)*7/20);
        endShape(CLOSE);
        beginShape();
        vertex((startMouseX+mouseX)/2, height-startMouseY);
        vertex(startMouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)/5, height-mouseY);
        vertex(startMouseX-(startMouseX-mouseX)*4/5, height-mouseY); 
        vertex(mouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        endShape(CLOSE);
        beginShape();
        vertex(width-(startMouseX+mouseX)/2, height-startMouseY);
        vertex(width-startMouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)/5), height-mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/5), height-mouseY);
        vertex(width-mouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        endShape(CLOSE);
    }
}

//draws a star
function drawStar(startMouseX, startMouseY, mouseX, mouseY) {
    beginShape();
    vertex((startMouseX+mouseX)/2, startMouseY);
    vertex(startMouseX-(startMouseX-mouseX)*2/5, startMouseY-(startMouseY-mouseY)*7/20);
    vertex(startMouseX, startMouseY-(startMouseY-mouseY)*7/20);
    vertex(startMouseX-(startMouseX-mouseX)*7/20, startMouseY-(startMouseY-mouseY)*11/20);
    vertex(startMouseX-(startMouseX-mouseX)/5, mouseY);
    vertex((startMouseX+mouseX)/2, startMouseY-(startMouseY-mouseY)*14/20);
    vertex(startMouseX-(startMouseX-mouseX)*4/5, mouseY);
    vertex(startMouseX-(startMouseX-mouseX)*13/20, startMouseY-(startMouseY-mouseY)*11/20);
    vertex(mouseX, startMouseY-(startMouseY-mouseY)*7/20);
    vertex(startMouseX-(startMouseX-mouseX)*3/5, startMouseY-(startMouseY-mouseY)*7/20);
    endShape(CLOSE);
    
    //mirroring based on the state of mirror
    if (mirror == 1) {
        beginShape();
        vertex(width-(startMouseX+mouseX)/2, startMouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*2/5), startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-startMouseX, startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*7/20), startMouseY-(startMouseY-mouseY)*11/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)/5), mouseY);
        vertex(width-(startMouseX+mouseX)/2, startMouseY-(startMouseY-mouseY)*14/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/5), mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*13/20), startMouseY-(startMouseY-mouseY)*11/20);
        vertex(width-mouseX, startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*3/5), startMouseY-(startMouseY-mouseY)*7/20);
        endShape(CLOSE);
    }
    else if (mirror == 2) {
        beginShape();
        vertex((startMouseX+mouseX)/2, height-startMouseY);
        vertex(startMouseX-(startMouseX-mouseX)*2/5, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)*7/20, height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(startMouseX-(startMouseX-mouseX)/5, height-mouseY);
        vertex((startMouseX+mouseX)/2, height-(startMouseY-(startMouseY-mouseY)*14/20));
        vertex(startMouseX-(startMouseX-mouseX)*4/5, height-mouseY);
        vertex(startMouseX-(startMouseX-mouseX)*13/20, height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(mouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)*3/5, height-(startMouseY-(startMouseY-mouseY)*7/20));
        endShape(CLOSE);
    }
    else if (mirror == 3) {
        beginShape();
        vertex(width-(startMouseX+mouseX)/2, startMouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*2/5), startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-startMouseX, startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*7/20), startMouseY-(startMouseY-mouseY)*11/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)/5), mouseY);
        vertex(width-(startMouseX+mouseX)/2, startMouseY-(startMouseY-mouseY)*14/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/5), mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*13/20), startMouseY-(startMouseY-mouseY)*11/20);
        vertex(width-mouseX, startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*3/5), startMouseY-(startMouseY-mouseY)*7/20);
        endShape(CLOSE);
        beginShape();
        vertex((startMouseX+mouseX)/2, height-startMouseY);
        vertex(startMouseX-(startMouseX-mouseX)*2/5, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)*7/20, height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(startMouseX-(startMouseX-mouseX)/5, height-mouseY);
        vertex((startMouseX+mouseX)/2, height-(startMouseY-(startMouseY-mouseY)*14/20));
        vertex(startMouseX-(startMouseX-mouseX)*4/5, height-mouseY);
        vertex(startMouseX-(startMouseX-mouseX)*13/20, height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(mouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)*3/5, height-(startMouseY-(startMouseY-mouseY)*7/20));
        endShape(CLOSE);
        beginShape();
        vertex(width-(startMouseX+mouseX)/2, height-startMouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*2/5), height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(width-startMouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*7/20), height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)/5), height-mouseY);
        vertex(width-(startMouseX+mouseX)/2, height-(startMouseY-(startMouseY-mouseY)*14/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/5), height-mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*13/20), height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(width-mouseX, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*3/5), height-(startMouseY-(startMouseY-mouseY)*7/20));
        endShape(CLOSE);
    }
}

//draws a electricity symbol
function drawShock(startMouseX, startMouseY, mouseX, mouseY) {
    beginShape();
    vertex(startMouseX, startMouseY-(startMouseY-mouseY)*2/20);
    vertex(startMouseX-(startMouseX-mouseX)*7/20, startMouseY-(startMouseY-mouseY)*7/20);
    vertex(startMouseX-(startMouseX-mouseX)*4/20, startMouseY-(startMouseY-mouseY)*8/20);
    vertex(startMouseX-(startMouseX-mouseX)*11/20, startMouseY-(startMouseY-mouseY)*13/20);
    vertex(startMouseX-(startMouseX-mouseX)*8/20, startMouseY-(startMouseY-mouseY)*14/20);
    vertex(mouseX, mouseY);
    vertex(startMouseX-(startMouseX-mouseX)*14/20, startMouseY-(startMouseY-mouseY)*12/20);
    vertex(startMouseX-(startMouseX-mouseX)*17/20, startMouseY-(startMouseY-mouseY)*11/20);
    vertex(startMouseX-(startMouseX-mouseX)*11/20, startMouseY-(startMouseY-mouseY)*6/20);
    vertex(startMouseX-(startMouseX-mouseX)*14/20, startMouseY-(startMouseY-mouseY)*5/20);
    vertex(startMouseX-(startMouseX-mouseX)*8/20, startMouseY);
    endShape(CLOSE);
    
    //mirroring based on the state of mirror
    if (mirror == 1) {
        beginShape();
        vertex(width-startMouseX, startMouseY-(startMouseY-mouseY)*2/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*7/20), startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/20), startMouseY-(startMouseY-mouseY)*8/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*11/20), startMouseY-(startMouseY-mouseY)*13/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*8/20), startMouseY-(startMouseY-mouseY)*14/20);
        vertex(width-mouseX, mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*14/20), startMouseY-(startMouseY-mouseY)*12/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*17/20), startMouseY-(startMouseY-mouseY)*11/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*11/20), startMouseY-(startMouseY-mouseY)*6/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*14/20), startMouseY-(startMouseY-mouseY)*5/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*8/20), startMouseY);
        endShape(CLOSE);
    }
    else if (mirror == 2) {
        beginShape();
        vertex(startMouseX, height-(startMouseY-(startMouseY-mouseY)*2/20));
        vertex(startMouseX-(startMouseX-mouseX)*7/20, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)*4/20, height-(startMouseY-(startMouseY-mouseY)*8/20));
        vertex(startMouseX-(startMouseX-mouseX)*11/20, height-(startMouseY-(startMouseY-mouseY)*13/20));
        vertex(startMouseX-(startMouseX-mouseX)*8/20, height-(startMouseY-(startMouseY-mouseY)*14/20));
        vertex(mouseX, height-mouseY);
        vertex(startMouseX-(startMouseX-mouseX)*14/20, height-(startMouseY-(startMouseY-mouseY)*12/20));
        vertex(startMouseX-(startMouseX-mouseX)*17/20, height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(startMouseX-(startMouseX-mouseX)*11/20, height-(startMouseY-(startMouseY-mouseY)*6/20));
        vertex(startMouseX-(startMouseX-mouseX)*14/20, height-(startMouseY-(startMouseY-mouseY)*5/20));
        vertex(startMouseX-(startMouseX-mouseX)*8/20, height-startMouseY);
        endShape(CLOSE);
    }
    else if (mirror == 3) {
        beginShape();
        vertex(width-startMouseX, startMouseY-(startMouseY-mouseY)*2/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*7/20), startMouseY-(startMouseY-mouseY)*7/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/20), startMouseY-(startMouseY-mouseY)*8/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*11/20), startMouseY-(startMouseY-mouseY)*13/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*8/20), startMouseY-(startMouseY-mouseY)*14/20);
        vertex(width-mouseX, mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*14/20), startMouseY-(startMouseY-mouseY)*12/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*17/20), startMouseY-(startMouseY-mouseY)*11/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*11/20), startMouseY-(startMouseY-mouseY)*6/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*14/20), startMouseY-(startMouseY-mouseY)*5/20);
        vertex(width-(startMouseX-(startMouseX-mouseX)*8/20), startMouseY);
        endShape(CLOSE);
        beginShape();
        vertex(startMouseX, height-(startMouseY-(startMouseY-mouseY)*2/20));
        vertex(startMouseX-(startMouseX-mouseX)*7/20, height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(startMouseX-(startMouseX-mouseX)*4/20, height-(startMouseY-(startMouseY-mouseY)*8/20));
        vertex(startMouseX-(startMouseX-mouseX)*11/20, height-(startMouseY-(startMouseY-mouseY)*13/20));
        vertex(startMouseX-(startMouseX-mouseX)*8/20, height-(startMouseY-(startMouseY-mouseY)*14/20));
        vertex(mouseX, height-mouseY);
        vertex(startMouseX-(startMouseX-mouseX)*14/20, height-(startMouseY-(startMouseY-mouseY)*12/20));
        vertex(startMouseX-(startMouseX-mouseX)*17/20, height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(startMouseX-(startMouseX-mouseX)*11/20, height-(startMouseY-(startMouseY-mouseY)*6/20));
        vertex(startMouseX-(startMouseX-mouseX)*14/20, height-(startMouseY-(startMouseY-mouseY)*5/20));
        vertex(startMouseX-(startMouseX-mouseX)*8/20, height-startMouseY);
        endShape(CLOSE);
        beginShape();
        vertex(width-startMouseX, height-(startMouseY-(startMouseY-mouseY)*2/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*7/20), height-(startMouseY-(startMouseY-mouseY)*7/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*4/20), height-(startMouseY-(startMouseY-mouseY)*8/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*11/20), height-(startMouseY-(startMouseY-mouseY)*13/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*8/20), height-(startMouseY-(startMouseY-mouseY)*14/20));
        vertex(width-mouseX, height-mouseY);
        vertex(width-(startMouseX-(startMouseX-mouseX)*14/20), height-(startMouseY-(startMouseY-mouseY)*12/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*17/20), height-(startMouseY-(startMouseY-mouseY)*11/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*11/20), height-(startMouseY-(startMouseY-mouseY)*6/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*14/20), height-(startMouseY-(startMouseY-mouseY)*5/20));
        vertex(width-(startMouseX-(startMouseX-mouseX)*8/20), height-startMouseY);
        endShape(CLOSE);
    }
}
