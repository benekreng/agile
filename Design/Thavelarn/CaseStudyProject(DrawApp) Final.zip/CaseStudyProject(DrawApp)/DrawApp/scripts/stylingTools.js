//Taken from https://stackoverflow.com/questions/5623838/rgb-to-hex-and-hex-to-rgb
function hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
        a: int(opacity)
    } : null;
}

//a function to set the correct styling values based on user input
function stylingTools() {
    //sets the size based on user input
    size = document.getElementById('size').parentElement.children[1].children[0].value;
    
    //sets the opacity based on user input
    opacity = document.getElementById('transparency').parentElement.children[1].children[0].value;
    
    //sets the color of drawings based on user input
    var tempColor = document.getElementById('color').parentElement.children[1].children[0].value;
    //the color value is converted from hex code to RGB color value
    tempColor = hexToRgb(tempColor);
    stroke(tempColor.r, tempColor.g, tempColor.b, tempColor.a);
    fill(tempColor.r, tempColor.g, tempColor.b, tempColor.a);
    
    //sets the background color based on user input
    backgroundColor = document.getElementById('background').parentElement.children[1].children[0].value;
    //only applies the background color if a change is detected and saves it
    //as a state that can be undo from and redo to.
    if (previousBackgroundColor != backgroundColor) {
        background(backgroundColor);
        previousBackgroundColor = backgroundColor;
        undoRedo.addState();
    }
}

//changing the usual color picker input element to match the application UI
//so color picker is now opened from clicking color icon
function displayColorPicker(id) {
    document.getElementById(id).parentElement.children[1].children[0].click();
}