function CutAndCopyTool(){
	this.name = "cutandcopy";
    var self = this;
	this.inSelection = true;
    this.selectedArea = {x: 0, y:0, w: 0, h: 0};
    this.selectedPixels = null;
    this.canPaste = false;
    this.updatePixel = false;
    
    loadPixels();
    
    //performing cut from the selected area based on user input
    select("#cut").mouseClicked(function() {
        updatePixels();
        self.inSelection = false;
        
        //appropriate changes in UI elements display
        select("#cut").style("display", "none");
        select("#copy").style("display", "none");
        select("#endpaste").style("display", "block");

        //draw a rectangle over it
        fill(255);
        stroke(255);
        rect(self.selectedArea.x, self.selectedArea.y, self.selectedArea.w, self.selectedArea.h);
        
        loadPixels();
    });

    //performing copy from the selected area based on user input
    select("#copy").mouseClicked(function() {
        updatePixels();
        self.inSelection = false;
        
        //appropriate changes in UI elements display
        select("#cut").style("display", "none");
        select("#copy").style("display", "none");
        select("#endpaste").style("display", "block");
    });
    
    //reseting to selection
    select("#endpaste").mouseClicked(function() {
        self.inSelection = true;
        
        //appropriate changes in UI elements display
        select("#cut").style("display", "block");
        select("#copy").style("display", "block");
        select("#endpaste").style("display", "none");

        selectMode = 0;
        loadPixels();
        self.selectedArea = {x: 0, y: 0, w: 0, h: 0};
    });

	//draws the selection area or paste copied or cut area to the screen 
	this.draw = function() {
		//only draw when mouse is clicked
        if (mouseIsPressed) {
            strokeWeight(3);
            
            //checking if user is in selection mode
			if (self.inSelection) {
                updatePixels();
                
                //draws selection area
                stroke(64, 64, 64);
                fill(64, 64, 64, 64);
                rect(self.selectedArea.x, self.selectedArea.y, self.selectedArea.w, self.selectedArea.h);
            }
            else {
                noStroke();
                if(self.canPaste) {
                    image(self.selectedPixels, mouseX-self.selectedArea.w/2, mouseY-self.selectedArea.h/2);
                }
            }
        }
	};
    
    //setting selection area starting position
    this.selectionStart = function() {
        self.selectedArea.x = mouseX;
        self.selectedArea.y = mouseY;
        updatePixels();
    }
    //updating selection area aize
    this.updateSelectionArea = function() {
        self.selectedArea.w = mouseX - self.selectedArea.x;
        self.selectedArea.h = mouseY - self.selectedArea.y;
    }
    //correctly saving the selected area that needs to be pasted
    this.setSelectionArea = function() {
        self.selectedArea.x = mouseX < self.selectedArea.x ? mouseX : self.selectedArea.x;
        self.selectedArea.y = mouseY < self.selectedArea.y ? mouseY : self.selectedArea.y;
        self.selectedArea.w = abs(self.selectedArea.w);
        self.selectedArea.h = abs(self.selectedArea.h);
        updatePixels();
        self.selectedPixels = get(self.selectedArea.x, self.selectedArea.y, self.selectedArea.w, self.selectedArea.h);
        rect(self.selectedArea.x, self.selectedArea.y, self.selectedArea.w, self.selectedArea.h);
    }
}

function mousePressed() {
    //calling selectionStart() based on mouse press
    if (toolbox.selectedTool.name == "cutandcopy" && toolbox.selectedTool.inSelection && canDraw) {
        toolbox.selectedTool.selectionStart();
    }
}

function mouseDragged() {
    //calling updateSelectionArea() based on mouse drag
    if (toolbox.selectedTool.name == "cutandcopy" && toolbox.selectedTool.inSelection && canDraw) {
        toolbox.selectedTool.updateSelectionArea();
    }
    toolbox.selectedTool.canPaste = false;
}


