//canvas variable
var c = null;

//variable for CCapture to record and export animation from animation tool
var animationCapturer = null;

//variables for constructor functions
var toolbox = null;
var helpers = null;
var undoRedo = null;
var anim = null;

//variables for styling functions
var previousBackgroundColor = null;
var backgroundColor = null;
var opacity = null;
var size = null;

//variables to affect the state of how and when you can draw
var mirror = null;
var canDraw = null;


function setup() {

	//create a canvas to fill the content div from index.html
	canvasContainer = select('#content');
	c = createCanvas(canvasContainer.size().width + 17, canvasContainer.size().height);
	c.parent("content");
    
    //disable canvas when mouse is not over canvas
    canDraw = true;
    
    select("footer").mouseOver(function() {
        canDraw = false;
    });
    select("header").mouseOver(function() {
        canDraw = false;
    });
    canvasContainer.mouseOver(function() {
        canDraw = true;
    });
    
    //set type of mirror to none
    mirror = 0;
    
    //set intial values for styling functions
    previousBackgroundColor = color('#FFFFFF');
    backgroundColor = color('#FFFFFF');
    background(backgroundColor);
    opacity = 255;
    stroke(0, 0, 0, opacity);
    size = 5;
    
	//create a toolbox for storing the tools
	toolbox = new Toolbox();

	//add the tools to the toolbox.
	toolbox.addTool(new FreehandTool());
	toolbox.addTool(new LineTool());
	toolbox.addTool(new SprayTool());
    toolbox.addTool(new ShapeTool());
    toolbox.addTool(new EraserTool());
    toolbox.addTool(new CutAndCopyTool());
    
    //create other contructor functions
	helpers = new HelperFunctions();
    undoRedo = new UndoRedoTool(50);
    anim = new AnimTool();
}

function draw() {
	//call the draw function from the selected tool.
	//hasOwnProperty is a javascript function that tests
	//if an object contains a particular method or property
	//if there isn't a draw method the app will alert the user
	if (toolbox.selectedTool.hasOwnProperty("draw") && canDraw) {
        //updating mirror and styling variables after user input
        stylingTools();
        mirrorTool();
        
        //calling tool specific draw function
		toolbox.selectedTool.draw();
	}
}

function mouseReleased() {
    //Used for undoRedoTool() to save the canvas on change
    if (toolbox.selectedTool.name != "cutandcopy" && canDraw) {
        undoRedo.addState();
    }
    
    //Used for cutAndCopyTool() to enable selection
    if (toolbox.selectedTool.name == "cutandcopy" && toolbox.selectedTool.inSelection && canDraw) {
        toolbox.selectedTool.setSelectionArea();
    }
    else {
        toolbox.selectedTool.canPaste = true;
    }
    
    
}