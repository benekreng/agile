//a tool for drawing straight lines to the screen. Allows the user to 
//preview the a line to the current mouse position before drawing the line 
//to the pixel array.
function LineTool() {
	this.name = "line";
	var startMouseX = -1;
	var startMouseY = -1;
	var drawing = false;

	//draws the line to the screen 
	this.draw = function() {
		//only draw when mouse is clicked
		if (mouseIsPressed) {
            strokeWeight(size);
			//if it's the start of drawing a new line
			if (startMouseX == -1) {
				startMouseX = mouseX;
				startMouseY = mouseY;
				drawing = true;
				//save the current pixel Array
				loadPixels();
			}
			else {
				//update the screen with the saved pixels to hide any
				//previous line between mouse pressed and released
				updatePixels();
                
				//draw the line
				line(startMouseX, startMouseY, mouseX, mouseY);
                
                //mirroring based on the state of mirror
                if (mirror == 1) {
                    line(width-startMouseX, startMouseY, width-mouseX, mouseY);
                }
                else if (mirror == 2) {
                    line(startMouseX, height-startMouseY, mouseX, height-mouseY);
                }
                else if (mirror == 3) {
                    line(width-startMouseX, startMouseY, width-mouseX, mouseY);
                    line(startMouseX, height-startMouseY, mouseX, height-mouseY);
                    line(width-startMouseX, height-startMouseY, width-mouseX, height-mouseY);
                }
			}
		}
		else if (drawing) {
			//save the pixels with the most recent line and reset the
			//drawing bool and start locations
			loadPixels();
			drawing = false;
			startMouseX = -1;
			startMouseY = -1;
		}
	};
}
