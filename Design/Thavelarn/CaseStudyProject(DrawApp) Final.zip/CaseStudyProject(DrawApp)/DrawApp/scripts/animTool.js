function AnimTool() {
    var frames = [];
    var currentFrame = -1;
    var currentFramePlaying = 0;
    var frameInterval = 1000;
    var frameSelect = select("#frames");
    var self = this;
    var playing = null;
    
    //displays the next fram of the animation
    var displayFrame = function() {
        if (currentFramePlaying < frames.length-1) {
            currentFramePlaying += 1;
            image(frames[currentFramePlaying], 0, 0);
            
            //adding canvas image to the animation save file
            if (animationCapturer != null) {
                animationCapturer.capture(c.canvas);
            }
        }
        else {
            //appropriate changes in UI elements display
            select("#pauseanim").style("display", "none");
            select("#stopanim").style("display", "none");
            select("#playanim").style("display", "block");
            
            //exporting the saved animation
            if (animationCapturer != null) {
                animationCapturer.stop();
                animationCapturer.save();
                animationCapturer = null;
            }
            
            clearInterval(playing);
            currentFramePlaying = 0;
            image(frames[currentFrame], 0, 0);
        }
    }
    
    //adds a frame to specific location based on user input
    select("#addframe").mouseClicked(function() {
        if (currentFrame == -1) {
            frames = [];
        }
        splice(frames, get(), currentFrame+1);
        currentFrame += 1;
        self.updateFrameList();
    });
    //saves any changes made to the selected frame
    select("#saveframe").mouseClicked(function() {
        frames[currentFrame] = get();
        self.updateFrameList();
    });
    //deletes the selected frame
    select("#deleteframe").mouseClicked(function() {
        frames.splice(currentFrame, 1);
        if (currentFrame != 0) {
            currentFrame -= 1;
        }
        image(frames[currentFrame], 0, 0);
        self.updateFrameList();
    });
    //plays the animation from the beginning
    select("#playanim").mouseClicked(function() {
        if (frames.length > 0) {
            image(frames[0], 0, 0);
            if (frames.length > 1) {
                //appropriate changes in UI elements display
                select("#pauseanim").style("display", "block");
                select("#stopanim").style("display", "block");
                select("#playanim").style("display", "none");

                playing = setInterval(displayFrame, frameInterval);
            }
        }
        
    });
    //pauses the animation
    select("#pauseanim").mouseClicked(function() {
        //appropriate changes in UI elements display
        select("#pauseanim").style("display", "none");
        select("#playanim").style("display", "block");
        
        clearInterval(playing);
    });
    //stops the animation
    select("#stopanim").mouseClicked(function() {
        //appropriate changes in UI elements display
        select("#pauseanim").style("display", "none");
        select("#stopanim").style("display", "none");
        select("#playanim").style("display", "block");
        
        clearInterval(playing);
        currentFramePlaying = 0;
        image(frames[currentFrame], 0, 0);
    });
    //saves the animation
    select("#saveanim").mouseClicked(function() {
        if (frames.length > 0) {
            //creating the CCapture object to record and export animation
            animationCapturer = new CCapture({
                framerate: select("#framerate").value(),
                format: 'gif',
                workersPath: './lib/',
                verbose: true
            });
            //Starting and saving the first canvas image
            animationCapturer.start();
            image(frames[0], 0, 0);
            animationCapturer.capture(c.canvas);
            if (frames.length > 1) {
                playing = setInterval(displayFrame, frameInterval);
            }
            else {
                animationCapturer.stop();
                animationCapturer.save();
            }
        }
    })
    
    //updates the number of frames stored in the UI
    this.updateFrameList = function() {
        while (document.getElementById('frames').options.length > 0) {
            document.getElementById('frames').remove(0);
            frameSelect.child();
        }
        for (var j = 0; j < frames.length; j++) {
            frameSelect.option(j+1, j);
        }
        if (frames.length > 0) {
            document.getElementById('frames').getElementsByTagName('option')[currentFrame].selected = true;
        }
    }
    
    //allows the user to select the current frame
    this.changeCurrentFrame = function() {
        currentFrame = (int)(frameSelect.value());
        image(frames[currentFrame], 0, 0);
    }
    
    //allows the user to select the frame rate the animation plays in
    this.updateFrameRate = function() {
        frameInterval = 1.0/((float)(select("#framerate").value())/1000.0);
    }
}