//seting the state of mirror by user input and display mirror lines
//appropriate to the state
function mirrorTool() {
    //vertical mirror only
    select("#verticalmirror").mouseClicked(function() {
        mirror = 1;
        select("#horizontal-line").style("display", "none");
        select("#vertical-line").style("display", "block");
    });
    //horizontal mirror only
    select("#horizontalmirror").mouseClicked(function() {
        mirror = 2;
        select("#vertical-line").style("display", "none");
        select("#horizontal-line").style("display", "block");
    });
    //both vertical and horizontal mirror active
    select("#bothmirror").mouseClicked(function() {
        mirror = 3;
        select("#vertical-line").style("display", "block");
        select("#horizontal-line").style("display", "block");
    });
    //no mirror active, default state
    select("#clearmirror").mouseClicked(function() {
        mirror = 0;
        select("#vertical-line").style("display", "none");
        select("#horizontal-line").style("display", "none");
    });
    
}