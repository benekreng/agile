function FreehandTool() {
	//set an icon and a name for the object
	this.name = "freehand";

	//to smoothly draw we'll draw a line from the previous mouse location
	//to the current mouse location. The following values store
	//the locations from the last frame. They are -1 to start with because
	//we haven't started drawing yet.
	var previousMouseX = -1;
	var previousMouseY = -1;

	this.draw = function(){
		//if the mouse is pressed
		if (mouseIsPressed){
            strokeWeight(size);
			//check if they previousX and Y are -1. set them to the current
			//mouse X and Y if they are.
			if (previousMouseX == -1){
				previousMouseX = mouseX;
				previousMouseY = mouseY;
			}
			//if we already have values for previousX and Y we can draw a
			//line from there to the current mouse location
			else {
				line(previousMouseX, previousMouseY, mouseX, mouseY);
                
                //mirroring based on the state of mirror
                if (mirror == 1) {
                    line(width-previousMouseX, previousMouseY, width-mouseX, mouseY);
                }
                else if (mirror == 2) {
                    line(previousMouseX, height-previousMouseY, mouseX, height-mouseY);
                }
                else if (mirror == 3) {
                    line(width-previousMouseX, previousMouseY, width-mouseX, mouseY);
                    line(previousMouseX, height-previousMouseY, mouseX, height-mouseY);
                    line(width-previousMouseX, height-previousMouseY, width-mouseX, height-mouseY);
                }
                
				previousMouseX = mouseX;
				previousMouseY = mouseY;
			}
		}
		//if the user has released the mouse we want to set the
		//previousMouse values back to -1.
		//try and comment out these lines and see what happens!
		else {
			previousMouseX = -1;
			previousMouseY = -1;
		}
	};
}